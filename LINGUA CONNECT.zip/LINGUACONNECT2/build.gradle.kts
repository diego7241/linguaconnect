// build.gradle.kts a nivel de proyecto

plugins {
    // Otros plugins que tengas
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.jetbrains.kotlin.android) apply false

    // Añadir el complemento de Google Services (sin aplicar en este nivel)
    id("com.google.gms.google-services") version "4.4.2" apply false
}

buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        // Clase necesaria para Firebase y Google Services
        classpath("com.google.gms:google-services:4.4.2")
    }
}

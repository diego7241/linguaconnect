package com.tuempresa.linguaconnect.ui

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.google.firebase.firestore.DocumentChange
import com.tuempresa.linguaconnect.R
import java.util.Date

class ChatActivity : AppCompatActivity() {

    private val db = Firebase.firestore
    private lateinit var chatRecyclerView: RecyclerView
    private lateinit var chatAdapter: ChatAdapter
    private var messages: MutableList<Message> = mutableListOf()

    // Define el ID del usuario actual
    private val currentUserId = "user123" // Cambia esto por el ID real del usuario

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        chatRecyclerView = findViewById(R.id.chatRecyclerView)
        chatAdapter = ChatAdapter(messages, currentUserId) // Pasa el ID del usuario
        chatRecyclerView.adapter = chatAdapter
        chatRecyclerView.layoutManager = LinearLayoutManager(this)

        listenForMessages()

        val sendButton = findViewById<Button>(R.id.sendButton)
        val messageEditText = findViewById<EditText>(R.id.messageEditText)

        sendButton.setOnClickListener {
            val messageText = messageEditText.text.toString()
            if (messageText.isNotEmpty()) {
                sendMessage(messageText)
                messageEditText.text.clear()
            }
        }
    }

    private fun listenForMessages() {
        db.collection("chats")
            .orderBy("timestamp")
            .addSnapshotListener { snapshot, e ->
                if (e != null) {
                    Log.w("Chat", "Listen failed.", e)
                    return@addSnapshotListener
                }

                messages.clear()

                snapshot?.documentChanges?.forEach { change ->
                    when (change.type) {
                        DocumentChange.Type.ADDED -> {
                            val message = change.document.toObject(Message::class.java)
                            messages.add(message)
                        }
                        DocumentChange.Type.MODIFIED -> {
                            // Manejar mensajes modificados aquí si es necesario
                        }
                        DocumentChange.Type.REMOVED -> {
                            // Manejar mensajes eliminados aquí si es necesario
                        }
                    }
                }
                chatAdapter.notifyDataSetChanged()
            }
    }

    private fun sendMessage(message: String) {
        val messageData = hashMapOf(
            "senderId" to currentUserId, // Cambia esto por el ID del usuario real
            "message" to message,
            "timestamp" to com.google.firebase.Timestamp.now() // Utiliza Timestamp aquí
        )

        db.collection("chats")
            .add(messageData)
            .addOnSuccessListener {
                Log.d("Chat", "Mensaje enviado con éxito")
            }
            .addOnFailureListener { e ->
                Log.w("Chat", "Error al enviar el mensaje", e)
            }
    }
}

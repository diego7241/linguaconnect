package com.tuempresa.linguaconnect.ui

import com.google.firebase.Timestamp
import java.text.SimpleDateFormat
import java.util.Locale

data class Message(
    val senderId: String = "",
    val message: String = "",
    val timestamp: Timestamp? = null // Asegúrate de que este sea de tipo Timestamp
) {
    // Método para obtener la fecha y hora como una cadena formateada
    fun getFormattedTimestamp(): String {
        return timestamp?.toDate()?.let {
            val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
            sdf.format(it)
        } ?: "Sin fecha"
    }
}
